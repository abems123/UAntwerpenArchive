//
// Created by AbEms on 12/10/2024.
//

#ifndef VEELTERMFUNCTIE_H
#define VEELTERMFUNCTIE_H

#include <cmath>
#include <iostream>
#include <vector>

using namespace std;

class VeeltermFunctie {
    string naam;
    vector<int> coefficienten;

public:
    void setNaam(const string &naam);

    [[nodiscard]] string getNaam() const;

    [[nodiscard]] int getGraad() const;

    [[nodiscard]] vector<int> getCoefficienten() const;

    void setCoefficienten(const vector<int> &coef);

    [[nodiscard]] string toString() const;

    [[nodiscard]] double berekenFunctiewaarde(double x) const;

    [[nodiscard]] VeeltermFunctie berekenAfgeleide() const;

    void som(const VeeltermFunctie &functie);

    void product(const VeeltermFunctie &functie);
};

inline void VeeltermFunctie::product(const VeeltermFunctie &functie) {
    int graad = getGraad();
    int fgraad = functie.getGraad();


    vector<int> newCoef(fgraad + graad + 1, 0);

    VeeltermFunctie f1;
    f1.setCoefficienten(newCoef);

    for (int i = graad; i >= 0; i--) { // i is
        for (int j = fgraad; j >= 0; j--) {
            if (newCoef[i + j] == 0)
                newCoef[i + j] = coefficienten[i] * functie.getCoefficienten()[j];
            else
                newCoef[i + j] += coefficienten[i] * functie.getCoefficienten()[j];
        }
    }

    // f1.coefficienten.at(0) = coefficienten[0] * functie.coefficienten[0];
    // f1.coefficienten.at(fgraad + graad) = coefficienten[graad] * functie.coefficienten[fgraad];

    setCoefficienten(newCoef);
}

inline void VeeltermFunctie::som(const VeeltermFunctie &functie) {
    vector<int> newCoefficienten;

    int newFctGraag;
    if (getGraad() > functie.getGraad())
        newFctGraag = getGraad();
    else if (getGraad() < functie.getGraad())
        newFctGraag = functie.getGraad();
    else
        newFctGraag = getGraad();


    for (int i = 0; i <= newFctGraag; i++) {
        int firstCoe = 0;
        int secondCoe = 0;

        if (i < coefficienten.size())
            firstCoe = coefficienten[i];

        if (i < functie.getCoefficienten().size())
            secondCoe = functie.getCoefficienten()[i];

        newCoefficienten.push_back(firstCoe + secondCoe);
    }

    setCoefficienten(newCoefficienten);
}


inline vector<int> VeeltermFunctie::getCoefficienten() const {
    return coefficienten;
}


inline void VeeltermFunctie::setNaam(const string &naam) {
    VeeltermFunctie::naam = naam;
}

inline string VeeltermFunctie::getNaam() const {
    return naam;
}

inline int VeeltermFunctie::getGraad() const {
    return coefficienten.size() - 1;
}

inline void VeeltermFunctie::setCoefficienten(const vector<int> &coef) {
    coefficienten = coef;
}

inline string VeeltermFunctie::toString() const {
    string result = getNaam() + "(x) = ";
    for (int i = 0, n = getGraad(); i < n; ++i) {
        int currentCoe = coefficienten[n - i];

        if (i == n - 1) {
            result += to_string(currentCoe) + " x ";
            if (coefficienten[0] > 0)
                result += "+ " + to_string(coefficienten[0]);
            else
                result += to_string(coefficienten[0]);
            break;
        }

        result += to_string(currentCoe) + " x^" + to_string(n - i) + ' ';
        if (coefficienten[n - i - 1] > 0)
            result += "+ ";
    }

    return result;
}

inline double VeeltermFunctie::berekenFunctiewaarde(const double x) const {
    double result = 0;
    for (int i = 0, n = getGraad(); i < n + 1; i++) {
        result += coefficienten[i] * pow(x, i);
    }
    return result;
}

inline VeeltermFunctie VeeltermFunctie::berekenAfgeleide() const {
    vector<int> newCoefficienten;
    for (int i = 1, n = getGraad(); i <= n; ++i) {
        newCoefficienten.push_back(coefficienten[i] * i);
    }
    VeeltermFunctie newFunctie;
    newFunctie.setCoefficienten(newCoefficienten);
    newFunctie.setNaam(naam + "\'");

    return newFunctie;
}


#endif //VEELTERMFUNCTIE_H
