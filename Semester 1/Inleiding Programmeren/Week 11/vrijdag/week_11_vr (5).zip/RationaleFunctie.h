//
// Created by AbEms on 12/10/2024.
//

#ifndef RATIONALEFUNCTIE_H
#define RATIONALEFUNCTIE_H



#include <iostream>
#include "VeeltermFunctie.h"

using namespace std;

class RationaleFunctie {
    string naam;
    VeeltermFunctie teller;
    VeeltermFunctie noemer;

public:
    string getNaam() const;

    void setNaam(const string &naam);

    void setTeller(const VeeltermFunctie &teller);

    void setNoemer(const VeeltermFunctie &noemer);

    string toString() const;

    [[nodiscard]] double berekenFunctiewaarde(double x) const;

    [[nodiscard]] RationaleFunctie berekenAfgeleide() const;
};

inline RationaleFunctie RationaleFunctie::berekenAfgeleide() const {
    RationaleFunctie result;
    const VeeltermFunctie tellerAfgeleide = teller.berekenAfgeleide();
    const VeeltermFunctie noemerAfgeleide = noemer.berekenAfgeleide();


    VeeltermFunctie newTeller = tellerAfgeleide;
    newTeller.product(noemer);

    VeeltermFunctie tempTeller = noemerAfgeleide;
    tempTeller.product(teller);

    vector<int> newCoefficienten;
    for (int &i : tempTeller.getCoefficienten())
        newCoefficienten.push_back(-i);

    tempTeller.setCoefficienten(newCoefficienten);

    newTeller.som(tempTeller);

    VeeltermFunctie newNoemer = noemer;
    newNoemer.product(noemer);

    result.setNaam(naam + "\'");
    result.setTeller(newTeller);
    result.setNoemer(newNoemer);

    return result;
}

inline string RationaleFunctie::getNaam() const {
    return naam;
}

inline void RationaleFunctie::setNaam(const string &naam) {
    RationaleFunctie::naam = naam;
}

inline void RationaleFunctie::setTeller(const VeeltermFunctie &teller) {
    RationaleFunctie::teller = teller;
}

inline void RationaleFunctie::setNoemer(const VeeltermFunctie &noemer) {
    bool notNul = false;
    for (const int i: noemer.getCoefficienten()) {
        notNul = i != 0;
        if (notNul) break;
    }
    if (!notNul) {
        cout << "Ongeldige noemer" << endl;
        return;
    }
    RationaleFunctie::noemer = noemer;
}

inline string RationaleFunctie::toString() const {
    const string tellerString = teller.toString();
    const string noemerString = noemer.toString();
    string result = getNaam() + "(x) = ( ";

    for (unsigned int i = 7, n = tellerString.size(); i < n; i++) {
        result += tellerString[i];
    }
    result += " ) / ( ";

    for (unsigned int i = 7, n = noemerString.size(); i < n; i++) {
        result += noemerString[i];
    }
    result += " )";

    return result;
}

inline double RationaleFunctie::berekenFunctiewaarde(double x) const {
    double tellerWaarde = teller.berekenFunctiewaarde(x);
    double noemerWaarde = noemer.berekenFunctiewaarde(x);
    if (noemerWaarde == 0) {
        cout << "Deze waarde ligt buiten het domein van de functie" << endl;
        return 0;
    }

    return tellerWaarde / noemerWaarde;
}




#endif //RATIONALEFUNCTIE_H
