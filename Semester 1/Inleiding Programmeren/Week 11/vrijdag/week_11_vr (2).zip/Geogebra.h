//
// Created by AbEms on 12/10/2024.
//

#ifndef GEOGEBRA_H
#define GEOGEBRA_H


#include <iostream>
#include <map>
#include "VeeltermFunctie.h"
#include "RationaleFunctie.h"

using namespace std;
class Geogebra {
    map<string, VeeltermFunctie*> veeltermFuncties;
    map<string, RationaleFunctie*> rationaleFuncties;

public:
    bool addFunctie(VeeltermFunctie* functie);
    bool addFunctie(RationaleFunctie* functie);
    void print();
};

inline bool Geogebra::addFunctie(VeeltermFunctie *functie) {
    string naam = functie->getNaam();

    for (auto pair : veeltermFuncties)
        if (naam == pair.first)
            return false;

    for (auto pair : rationaleFuncties)
        if (naam == pair.first)
            return false;

    veeltermFuncties[functie->getNaam()] = functie;
    return true;
}

inline bool Geogebra::addFunctie(RationaleFunctie *functie) {
    string naam = functie->getNaam();
    for (auto pair : veeltermFuncties)
        if (naam == pair.first)
            return false;

    for (auto pair : rationaleFuncties)
        if (naam == pair.first)
            return false;

    rationaleFuncties[functie->getNaam()] = functie;
    return true;
}

inline void Geogebra::print() {
    for (const auto f : veeltermFuncties) {
        cout << f.second->toString() << endl;
    }

    for (const auto f : rationaleFuncties) {
        cout << f.second->toString() << endl;
    }
}




#endif //GEOGEBRA_H
