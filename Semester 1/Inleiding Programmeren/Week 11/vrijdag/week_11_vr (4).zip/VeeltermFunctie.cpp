//
// Created by AbEms on 12/10/2024.
//

#include "VeeltermFunctie.h"
