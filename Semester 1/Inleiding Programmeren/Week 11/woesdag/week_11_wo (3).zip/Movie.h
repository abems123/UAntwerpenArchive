//
// Created by AbEms on 12/4/2024.
//

#ifndef MOVIE_H
#define MOVIE_H

#include <string>
#include "Director.h"
#include "Actor.h"
#include <vector>
using namespace std;

class Movie
{
    int year;
    Director *director;
    string title;
    string genre;
    vector<Actor *> actors;
    double rating;

public:
    Movie() = default;
    Movie(const int year, Director *const &director, const string &title, const string &genre,
          const vector<Actor *> &actors,
          const double rating)
    {
        this->year = year;
        this->director = director;
        this->title = title;
        this->genre = genre;
        this->actors = actors;
        this->rating = rating;
    }

    int getYear() const;
    Director *getDirector() const;
    string getTitle() const;
    string getGenre() const;
    vector<Actor *> getActors() const;
    double getRating() const;
    void setYear(int year);
    void setDirector(Director *const &director);
    void setTitle(const string &title);
    void setGenre(const string &genre);
    void setActors(const vector<Actor *> &actors);
    void setRating(const double &rating);
    string toString() const;

    void starring(Actor *const &actor);
};

inline void Movie::starring(Actor *const &actor)
{
    actors.push_back(actor);
}

inline string Movie::toString() const
{
    return title + " (" + to_string(year) + ')';
}

inline int Movie::getYear() const
{
    return year;
}

inline Director *Movie::getDirector() const
{
    return director;
}

inline string Movie::getTitle() const
{
    return title;
}

inline string Movie::getGenre() const
{
    return genre;
}

inline vector<Actor *> Movie::getActors() const
{
    return actors;
}

inline double Movie::getRating() const
{
    return rating;
}

inline void Movie::setYear(const int year)
{
    Movie::year = year;
}

inline void Movie::setDirector(Director *const &director)
{
    Movie::director = director;
}

inline void Movie::setTitle(const string &title)
{
    Movie::title = title;
}

inline void Movie::setGenre(const string &genre)
{
    Movie::genre = genre;
}

inline void Movie::setActors(const vector<Actor *> &actors)
{
    Movie::actors = actors;
}

inline void Movie::setRating(const double &rating)
{
    Movie::rating = rating;
}

#endif // MOVIE_H
