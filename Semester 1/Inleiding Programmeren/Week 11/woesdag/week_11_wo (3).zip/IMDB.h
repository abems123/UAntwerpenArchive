//
// Created by AbEms on 12/5/2024.
//

#ifndef IMDB_H
#define IMDB_H


#include <string>
#include <vector>

#include "Movie.h"

using namespace std;

class IMDB {
    vector<Movie *> movies;

public:
    IMDB() = default;

    explicit IMDB(const vector<Movie *> &movies) {
        this->movies = movies;
    }

    void addMovie(Movie *film);

    [[nodiscard]] Movie *getBest() const;

    [[nodiscard]] vector<Movie*> getSimilar(Movie *movie) const;

    [[nodiscard]] string toString() const;
};

inline void IMDB::addMovie(Movie *film) {
    movies.push_back(film);
}

inline string IMDB::toString() const {
    string result;
    for (const auto movie: movies) {
        result += movie->toString() + '\n';
    }
    return result;
}

inline Movie* IMDB::getBest() const {
    double rating = 0;
    Movie* best = new Movie();
    for (const auto m: movies) {
        if (m->getRating() > rating) {
            rating = m->getRating();
            best = m;
        }
    }
    return best;
}

inline vector<Movie*> IMDB::getSimilar(Movie *movie) const {
    vector<Movie*> similars;
    for (Movie *m: movies) {
        if (m->getGenre() == movie->getGenre() || abs(m->getRating() - movie->getRating()) <= 1) {
            similars.push_back(m);
        }
    }
    return similars;
}


#endif //IMDB_H
