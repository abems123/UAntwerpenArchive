//
// Created by AbEms on 12/5/2024.
//

#ifndef ACTOR_H
#define ACTOR_H



#include<iostream>
using namespace std;

class Actor {
    string firstname;
    string lastname;

public:
    Actor(const string &firstname, const string &lastname) {
        this->firstname = firstname;
        this->lastname = lastname;
    }
};



#endif //ACTOR_H
