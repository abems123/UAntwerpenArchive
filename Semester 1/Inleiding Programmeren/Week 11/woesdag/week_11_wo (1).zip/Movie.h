//
// Created by AbEms on 12/4/2024.
//

#ifndef MOVIE_H
#define MOVIE_H

#include <string>
#include <vector>
using namespace std;

class Movie
{
    int year;
    string director;
    string title;
    string genre;
    vector<string> actors;
    double rating;

public:
    Movie() = default;
    Movie(const int year, const string &director, const string &title, const string &genre,
          const vector<string> &actors,
          const double rating)
    {
        this->year = year;
        this->director = director;
        this->title = title;
        this->genre = genre;
        this->actors = actors;
        this->rating = rating;
    }

    int getYear() const;
    string getDirector() const;
    string getTitle() const;
    string getGenre() const;
    vector<string> getActors() const;
    double getRating() const;
    void setYear(int year);
    void setDirector(const string &director);
    void setTitle(const string &title);
    void setGenre(const string &genre);
    void setActors(const vector<string> &actors);
    void setRating(const double &rating);
    string toString() const;

    void starring(const string &actor);
};

inline void Movie::starring(const string &actor)
{
    actors.push_back(actor);
}

inline string Movie::toString() const
{
    return title + " (" + to_string(year) + ')';
}

inline int Movie::getYear() const
{
    return year;
}

inline string Movie::getDirector() const
{
    return director;
}

inline string Movie::getTitle() const
{
    return title;
}

inline string Movie::getGenre() const
{
    return genre;
}

inline vector<string> Movie::getActors() const
{
    return actors;
}

inline double Movie::getRating() const
{
    return rating;
}

inline void Movie::setYear(const int year)
{
    Movie::year = year;
}

inline void Movie::setDirector(const string &director)
{
    Movie::director = director;
}

inline void Movie::setTitle(const string &title)
{
    Movie::title = title;
}

inline void Movie::setGenre(const string &genre)
{
    Movie::genre = genre;
}

inline void Movie::setActors(const vector<string> &actors)
{
    Movie::actors = actors;
}

inline void Movie::setRating(const double &rating)
{
    Movie::rating = rating;
}

#endif // MOVIE_H
