//
// Created by AbEms on 12/26/2024.
//

#ifndef PROFESSOR_H
#define PROFESSOR_H
#include <string>
#include <vector>


class Cursus;
using namespace std;

class Professor {
    string voornaam;
    string achternaam;
    vector<Cursus*> cursussen;

public:
    Professor(const string &voornaam, const string &achternaam)
        : voornaam(voornaam),
          achternaam(achternaam) {
    }

    [[nodiscard]] string getVoornaam() const;

    [[nodiscard]] string getAchternaam() const;

    [[nodiscard]] string toString() const;

    void geeft(Cursus* c);
};



inline string Professor::getVoornaam() const {
    return voornaam;
}

inline string Professor::getAchternaam() const {
    return achternaam;
}

inline string Professor::toString() const {
    return "Professor" + voornaam + ' ' + achternaam;
}

inline void Professor::geeft(Cursus *c) {
    cursussen.push_back(c);
}
#endif //PROFESSOR_H
