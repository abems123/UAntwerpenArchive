//
// Created by AbEms on 12/24/2024.
//

#ifndef STUDENT_H
#define STUDENT_H

#include <map>
#include <string>

#include "Persoon.h"

class Cursus;

using namespace std;

class Student: public Persoon {
    string rolnummer;
    map<string, Cursus *> cursussen;
    int studiePunten = 0;

public:
    Student(const string &v, const string &a, const string &r): Persoon(v, a) {
        rolnummer = r;
    }

    [[nodiscard]] string getVoornaam() const;

    [[nodiscard]] string getAchternaam() const;

    [[nodiscard]] string getRolnummer() const;

    [[nodiscard]] string toString() const;

    bool schrijfIn(Cursus *c);

    bool schrijfUit(Cursus *c);

    [[nodiscard]] int getStudiepunten() const;
};

inline string Student::toString() const {
    return voornaam + ' ' + achternaam + '(' + rolnummer + ')';
}


inline string Student::getRolnummer() const {
    return rolnummer;
}

inline string Student::getVoornaam() const {
    return voornaam;
}

inline string Student::getAchternaam() const {
    return achternaam;
}

#endif //STUDENT_H
