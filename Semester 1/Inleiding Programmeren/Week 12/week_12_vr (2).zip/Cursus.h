//
// Created by AbEms on 12/24/2024.
//

#ifndef CURSUS_H
#define CURSUS_H

#include <string>
#include <vector>

class Student;
using namespace std;

class Cursus {
    string afkoring;
    string naam;
    int studiepunten = 0;
    vector<Student *> studenten;

public:
    Cursus(const string &af, const string &naam, const int punten): afkoring(af),
        naam(naam),
        studiepunten(punten) {
    }

    [[nodiscard]] string getAfkoring() const;

    [[nodiscard]] string getNaam() const;

    [[nodiscard]] unsigned short getStudiepunten() const;

    [[nodiscard]] string toString() const;

    void voegToe(Student *student);

    void verwijder(const Student *student);

    void print() const;
};

inline string Cursus::getAfkoring() const {
    return afkoring;
}

inline string Cursus::getNaam() const {
    return naam;
}

inline unsigned short Cursus::getStudiepunten() const {
    return studiepunten;
}

inline string Cursus::toString() const {
    return naam + " - " + afkoring + " (" + to_string(studiepunten) + ')';
}

inline void Cursus::voegToe(Student *student) {
    studenten.push_back(student);
}


#endif //CURSUS_H
