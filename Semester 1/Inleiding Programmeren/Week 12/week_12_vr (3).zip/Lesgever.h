//
// Created by AbEms on 12/26/2024.
//

#ifndef LESGEVER_H
#define LESGEVER_H
#include <vector>

#include "Persoon.h"


class Lesgever: public Persoon{

protected:
    vector<Cursus*> cursussen;

public:
    Lesgever(const string &voornaam, const string &achternaam)
        : Persoon(voornaam, achternaam) {
    }

    void geeft(Cursus* c);
};

inline void Lesgever::geeft(Cursus *c) {
    cursussen.push_back(c);
}


#endif //LESGEVER_H
