//
// Created by AbEms on 12/26/2024.
//

#ifndef PROFESSOR_H
#define PROFESSOR_H
#include <string>
#include <vector>

#include "Lesgever.h"

class Assistent;
class Cursus;

using namespace std;

class Professor: public Lesgever {
    vector<Assistent*> assistenten;

public:
    Professor(const string &voornaam, const string &achternaam)
        : Lesgever(voornaam, achternaam) {
    }

    [[nodiscard]] string toString() const;


    void voegAssistenToe(Assistent* a);
};

inline string Professor::toString() const {
    return "Professor " + voornaam + ' ' + achternaam;
}


#endif //PROFESSOR_H
