//
// Created by AbEms on 12/24/2024.
//
#include <iostream>

#include "Cursus.h"
#include "Student.h"


void Cursus::verwijder(const Student *student) {
    for (auto i = studenten.begin();; ++i) {
        if ((*i)->getRolnummer() == student->getRolnummer()) {
            studenten.erase(i);
            break;
        }
    }
}

void Cursus::print() const {
    cout << this->toString() << endl;
    for (const auto s: studenten) {
        cout << '\t' + s->toString() << endl;
    }
}