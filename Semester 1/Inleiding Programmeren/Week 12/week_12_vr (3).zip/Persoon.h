//
// Created by AbEms on 12/26/2024.
//

#ifndef PERSOON_H
#define PERSOON_H
#include <string>

class Cursus;
using namespace std;

class Persoon {
protected:
    string voornaam;
    string achternaam;

public:
    Persoon(const string &voornaam, const string &achternaam): voornaam(voornaam), achternaam(achternaam) {
    }

    [[nodiscard]] string getVoornaam() const;

    [[nodiscard]] string getAchternaam() const;

    [[nodiscard]] string toString() const;
};

inline string Persoon::getVoornaam() const {
    return voornaam;
}

inline string Persoon::getAchternaam() const {
    return achternaam;
}

inline string Persoon::toString() const {
    return voornaam + ' ' + achternaam;
}


#endif //PERSOON_H
