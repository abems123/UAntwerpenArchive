//
// Created by AbEms on 12/24/2024.
//

#include "Student.h"
#include "Cursus.h"


bool Student::schrijfIn(Cursus *c) {
    if (studiePunten + c->getStudiepunten() <= 60) {
        cursussen[c->getAfkoring()] = c;
        c->voegToe(this);
        studiePunten += c->getStudiepunten();
        return true;
    }

    return false;
}

bool Student::schrijfUit(Cursus *c) {
    for (const auto &[afk, _]: cursussen) {
        if (afk == c->getAfkoring()) {
            c->verwijder(this);
            return true;
        }
    }
    return false;
}

int Student::getStudiepunten() const {
    int result = 0;
    for (const auto [fst, snd]: cursussen) {
        result += snd->getStudiepunten();
    }
    return result;
}

void Student::showHomepage() const {
    cout << toString() <<" is een student van de UAntwerpen en volgt" << endl;

    for (const auto &c: cursussen) {
        cout << "- " + c.second->toString() << endl;
    }
}
