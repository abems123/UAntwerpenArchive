//
// Created by AbEms on 12/26/2024.
//

#ifndef LESGEVER_H
#define LESGEVER_H
#include <vector>

#include "Cursus.h"
#include "Persoon.h"


class Lesgever : public Persoon {
protected:
    vector<Cursus *> cursussen;

public:
    Lesgever(const string &voornaam, const string &achternaam)
        : Persoon(voornaam, achternaam) {
    }

    void geeft(Cursus *c);

    void showHomepage() const override;
};

inline void Lesgever::geeft(Cursus *c) {
    cursussen.push_back(c);
}

inline void Lesgever::showHomepage() const {
    Persoon::showHomepage();
    cout << " is een lesgever op de UAntwerpen en geeft" << endl;
}


#endif //LESGEVER_H
