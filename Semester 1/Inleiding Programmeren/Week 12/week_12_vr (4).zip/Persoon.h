//
// Created by AbEms on 12/26/2024.
//

#ifndef PERSOON_H
#define PERSOON_H
#include <iostream>
#include <string>
#include <vector>

class Cursus;
using namespace std;

class Persoon {
protected:
    string voornaam;
    string achternaam;

public:
    virtual ~Persoon() = default;

    Persoon(const string &voornaam, const string &achternaam): voornaam(voornaam), achternaam(achternaam) {
    }

    [[nodiscard]] string getVoornaam() const;

    [[nodiscard]] string getAchternaam() const;

    [[nodiscard]] string toString() const;

    virtual void showHomepage() const;
};

inline string Persoon::getVoornaam() const {
    return voornaam;
}

inline string Persoon::getAchternaam() const {
    return achternaam;
}

inline string Persoon::toString() const {
    return voornaam + ' ' + achternaam;
}

inline void Persoon::showHomepage() const {
    cout << toString();
}


#endif //PERSOON_H
