//
// Created by AbEms on 12/26/2024.
//

#ifndef PROFESSOR_H
#define PROFESSOR_H
#include <string>
#include <vector>

#include "Assistent.h"
#include "Lesgever.h"

class Assistent;
class Cursus;

using namespace std;

class Professor : public Lesgever {
    vector<Assistent *> assistenten;

public:
    Professor(const string &voornaam, const string &achternaam)
        : Lesgever(voornaam, achternaam) {
    }

    [[nodiscard]] string toString() const;

    void voegAssistentToe(Assistent *a);

    void showHomepage() const override;
};

inline string Professor::toString() const {
    return "Professor " + voornaam + ' ' + achternaam;
}

inline void Professor::voegAssistentToe(Assistent *a) {
    assistenten.push_back(a);
}

inline void Professor::showHomepage() const {
    Lesgever::showHomepage();

    for (const auto c: cursussen) {
        cout << "- " + c->toString() << " (";
        for (int i = 0, n = assistenten.size(); i < n; i++) {
            cout << assistenten[i]->toString();
            if (i != n - 1) cout << ", ";
        }
        cout << ')' << endl;
    }
}


#endif //PROFESSOR_H
