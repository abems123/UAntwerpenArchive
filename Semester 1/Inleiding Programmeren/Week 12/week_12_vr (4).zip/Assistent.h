//
// Created by AbEms on 12/26/2024.
//

#ifndef ASSISTENT_H
#define ASSISTENT_H
#include "Lesgever.h"

class Professor;

class Assistent : public Lesgever {
    Professor *begeleider;

public:
    Assistent(const string &voornaam, const string &achternaam)
        : Lesgever(voornaam, achternaam) {
    }

    [[nodiscard]] Professor *getBegeleider() const;

    void setBegeleider(Professor *const begeleider);

    void showHomepage() const override;
};

inline Professor *Assistent::getBegeleider() const {
    return begeleider;
}

inline void Assistent::setBegeleider(Professor *const begeleider) {
    this->begeleider = begeleider;
}




#endif //ASSISTENT_H
